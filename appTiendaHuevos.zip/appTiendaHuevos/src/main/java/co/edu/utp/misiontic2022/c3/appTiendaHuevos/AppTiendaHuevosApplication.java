package co.edu.utp.misiontic2022.c3.appTiendaHuevos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppTiendaHuevosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppTiendaHuevosApplication.class, args);
	}

}
