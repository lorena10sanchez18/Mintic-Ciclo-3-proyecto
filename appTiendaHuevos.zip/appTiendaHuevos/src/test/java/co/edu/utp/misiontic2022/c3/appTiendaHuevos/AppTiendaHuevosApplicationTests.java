package co.edu.utp.misiontic2022.c3.appTiendaHuevos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppTiendaHuevosApplicationTests {

	@Test
	void contextLoads() {
	}

}
